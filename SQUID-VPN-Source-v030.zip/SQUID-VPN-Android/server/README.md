# One-node WireGuard test server

This is a bootstrap for one Ubuntu 22.04/24.04 VPS you own. It does not create a cloud account or VPS, and it does not provide a public VPN endpoint by itself.

## Free-tier note
Check the provider's current free-tier eligibility, region availability, bandwidth quotas, and payment-card requirements yourself. Do not assume a free VM exists in India. If no free India VM is available, choose a supported region for testing or use a low-cost paid VPS after checking pricing.

## Provision
1. Create one Ubuntu 22.04/24.04 VM with a public IPv4 address.
2. Permit inbound UDP 51820 and TCP 22 in the provider firewall/security group.
3. SSH into the VM and copy this script.
4. Review it, then run: `sudo bash wireguard-one-node-ubuntu.sh`
5. Keep `/etc/wireguard/server_private.key` secret. Back it up securely.

The script enables IPv4/IPv6 forwarding, configures a WireGuard interface and basic IPv4 NAT. It is a test baseline, not a hardened commercial VPN service. Before real users: add firewall policy, monitoring, patching, abuse controls, DNS strategy, IPv6 egress policy, key rotation/revocation, and security review.

## Client profile
Generate a separate private/public keypair per Android device. Add the device public key as a `[Peer]` on the server. Deliver a client config containing that device's private key only over authenticated HTTPS to that device. Never bake shared keys into the APK or commit configs/keys to source control.
