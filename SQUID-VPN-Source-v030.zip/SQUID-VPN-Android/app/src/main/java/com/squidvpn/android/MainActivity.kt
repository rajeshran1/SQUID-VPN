package com.squidvpn.android

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch

private val Ink = Color(0xFF07111F)
private val SurfaceDark = Color(0xFF142337)
private val Aqua = Color(0xFF40E0D0)
private val Soft = Color(0xFF9AAFC4)

class MainActivity : ComponentActivity() {
    private lateinit var controller: WireGuardController
    private var pendingProfile: VpnProfile? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        controller = WireGuardController((application as SquidVpnApplication).backend)

        setContent {
            SquidVpnScreen(
                onConnectRequest = { country ->
                    // No demo/fake profile is embedded. Until the control plane is deployed,
                    // show a clear unavailable state rather than claiming a VPN is connected.
                    showMessage("No live $country server is provisioned yet. Add the control-plane API and issue a unique WireGuard profile first.")
                },
                onDisconnect = {
                    lifecycleScope.launch {
                        runCatching { controller.disconnect() }
                            .onSuccess { showMessage(it) }
                            .onFailure { showMessage("Disconnect failed: ${it.message}") }
                    }
                }
            )
        }
    }

    private fun showMessage(message: String) {
        runOnUiThread {
            android.app.AlertDialog.Builder(this)
                .setTitle("SQUID VPN")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show()
        }
    }
}

@Composable
private fun SquidVpnScreen(
    onConnectRequest: (String) -> Unit,
    onDisconnect: () -> Unit
) {
    var selected by remember { mutableStateOf("India") }
    val countries = listOf(
        "India" to "IN", "Singapore" to "SG", "United States" to "US",
        "United Kingdom" to "GB", "Germany" to "DE", "France" to "FR",
        "Netherlands" to "NL", "Japan" to "JP", "Canada" to "CA",
        "Australia" to "AU", "Switzerland" to "CH"
    )
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Aqua, background = Ink, surface = SurfaceDark,
        onPrimary = Ink, onBackground = Color.White, onSurface = Color.White
    )) {
        var showDisconnectConfirm by remember { mutableStateOf(false) }
        Column(
            modifier = Modifier.fillMaxSize().background(Ink).padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(24.dp))
            Icon(Icons.Default.Shield, contentDescription = null, tint = Aqua, modifier = Modifier.size(38.dp))
            Text("SQUID VPN", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black)
            Text("PRIVATE CONNECTION • POWERED BY WIREGUARD", color = Soft, fontSize = 9.sp)
            Spacer(Modifier.height(26.dp))
            Box(
                modifier = Modifier.size(148.dp).background(SurfaceDark, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Lock, contentDescription = null, tint = Aqua, modifier = Modifier.size(62.dp))
            }
            Spacer(Modifier.height(12.dp))
            Text("Ready to connect", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("Select a configured server location", color = Soft, fontSize = 12.sp)
            Spacer(Modifier.height(22.dp))
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Public, contentDescription = null, tint = Aqua)
                Spacer(Modifier.width(8.dp))
                Text("SERVER LOCATIONS", color = Soft, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text("11 locations shown", color = Soft, fontSize = 10.sp)
            }
            Spacer(Modifier.height(8.dp))
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth()
                    .background(SurfaceDark, RoundedCornerShape(16.dp)).padding(horizontal = 14.dp)
            ) {
                items(countries) { (country, code) ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f).padding(vertical = 5.dp)) {
                            Text(country, color = Color.White, fontSize = 14.sp)
                            Text("$code • Server provisioning pending", color = Soft, fontSize = 10.sp)
                        }
                        RadioButton(selected == country, onClick = { selected = country })
                    }
                    HorizontalDivider(color = Color(0xFF2A3B50))
                }
            }
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = { onConnectRequest(selected) },
                modifier = Modifier.fillMaxWidth().height(52.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Aqua),
                shape = RoundedCornerShape(15.dp)
            ) {
                Text("CONNECT", color = Ink, fontWeight = FontWeight.ExtraBold)
            }
            Spacer(Modifier.height(14.dp))
            Text("UI + WireGuard engine integrated • Live servers not yet provisioned", color = Soft, fontSize = 10.sp)
            Spacer(Modifier.height(16.dp))
        }
    }
}
