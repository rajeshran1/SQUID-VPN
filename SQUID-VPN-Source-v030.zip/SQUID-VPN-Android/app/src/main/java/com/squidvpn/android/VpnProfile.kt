package com.squidvpn.android

/**
 * A profile must be supplied by your authenticated control-plane API.
 * Never ship a shared/private WireGuard key inside the app.
 */
data class VpnProfile(
    val id: String,
    val displayName: String,
    val countryCode: String,
    val config: String
)

data class ServerOption(
    val id: String,
    val name: String,
    val countryCode: String,
    val city: String,
    val isConfigured: Boolean = false
)
