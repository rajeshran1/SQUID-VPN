package com.squidvpn.android

import android.app.Application
import com.wireguard.android.backend.Backend
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream

class SquidVpnApplication : Application() {
    lateinit var backend: Backend
        private set

    override fun onCreate() {
        super.onCreate()
        backend = GoBackend(this)
    }
}

/**
 * Thin lifecycle wrapper around WireGuard's official GoBackend.
 * The caller must first obtain a per-device profile from the API and
 * request Android's VPN permission via VpnService.prepare(activity).
 */
class WireGuardController(
    private val backend: Backend
) {
    private class ProfileTunnel(private val tunnelName: String) : Tunnel {
        @Volatile private var currentState = Tunnel.State.DOWN

        override fun getName(): String = tunnelName
        override fun onStateChange(newState: Tunnel.State) {
            currentState = newState
        }
        fun state(): Tunnel.State = currentState
    }

    private var activeTunnel: ProfileTunnel? = null

    suspend fun connect(profile: VpnProfile): String = withContext(Dispatchers.IO) {
        require(profile.config.contains("[Interface]")) { "Invalid WireGuard profile" }
        require(profile.config.contains("[Peer]")) { "WireGuard peer is missing" }

        val tunnel = ProfileTunnel("squid-${profile.id.take(24).replace(Regex("[^A-Za-z0-9_-]"), "")}")
        val config = Config.parse(ByteArrayInputStream(profile.config.toByteArray(Charsets.UTF_8)))
        backend.setState(tunnel, Tunnel.State.UP, config)
        activeTunnel = tunnel
        "Connected"
    }

    suspend fun disconnect(): String = withContext(Dispatchers.IO) {
        val tunnel = activeTunnel ?: return@withContext "Already disconnected"
        backend.setState(tunnel, Tunnel.State.DOWN, null)
        activeTunnel = null
        "Disconnected"
    }

    suspend fun currentState(): String = withContext(Dispatchers.IO) {
        val tunnel = activeTunnel ?: return@withContext "DOWN"
        backend.getState(tunnel).name
    }
}
