# SQUID VPN — Android test client scaffold 0.3.0

## What is included
- SQUID VPN branded Android/Kotlin + Jetpack Compose project.
- 11 planned country locations in the UI.
- Official WireGuard Android tunnel library (`com.wireguard.android:tunnel:1.0.20260102`).
- GoBackend controller wrapper that can bring up/down a tunnel when supplied a valid, per-device WireGuard profile.
- One-node Ubuntu WireGuard bootstrap script in `server/`.

## What is not yet live
No cloud VM has been created, no VPN endpoint is running, no control-plane API exists, and no installable APK has been built or device-tested. The app correctly does not pretend the server list is live. The free/testing budget means start with one server, not 10+ countries.

## Build APK
1. Install Android Studio stable and Android SDK Platform 35.
2. Open this project folder and allow Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. For release APK, create a signing key in Android Studio and keep it private.

The source ZIP was prepared here; a real Gradle build still needs to run in Android Studio/CI with Android SDK and dependency access. Do not distribute until build, device, privacy and security tests pass.

## First server
See `server/README.md` and `server/wireguard-one-node-ubuntu.sh`. This requires an Ubuntu VPS you control and provider firewall access. A free tier is not guaranteed in the desired region and may require billing details.

## Production blockers
- Authenticated HTTPS control-plane API for login, entitlement, server health and client config delivery.
- Android `VpnService.prepare()` consent flow before calling GoBackend.
- Unique per-device key generation, secure storage, config retrieval and revocation.
- Foreground service/lifecycle, reconnect and state UI.
- DNS/IPv6 leak policy, kill-switch/Always-on testing, abuse protection, monitoring, privacy policy and security audit.
- Additional country nodes and capacity testing.

## Security
Never store server private keys or shared client keys in the APK, Git repository, or chat. Do not use public free VPN configs from unknown sources. Do not claim "no logs" unless the actual infrastructure and policy support it.

## Official WireGuard references
- https://www.wireguard.com/embedding/
- https://github.com/WireGuard/wireguard-android
